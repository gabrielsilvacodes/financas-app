export const CATEGORIAS = [
  { id: "1", nome: "Alimentação", cor: "#F4A261" },
  { id: "2", nome: "Transporte", cor: "#2A9D8F" },
  { id: "3", nome: "Lazer", cor: "#E9C46A" },
  { id: "4", nome: "Outros", cor: "#264653" },
];
